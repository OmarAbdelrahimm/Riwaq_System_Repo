/**
 * RUWAQ: Bab Zuwayla Production Remotion Component
 * Implements deterministic 3D architectural rendering via @remotion/three and React Three Fiber
 * Frame-by-frame reproducible at arbitrary out-of-order frame positions
 */

import React, { useMemo } from 'react';
import { useCurrentFrame, useVideoConfig, interpolate } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import * as THREE from 'three';

import { ViewerState } from './types.ts';
import { createMaterialPalette } from './three/materials.ts';
import { createSemicircularTower } from './three/geometry/tower.ts';
import { createCentralPortal } from './three/geometry/portal.ts';
import { createGateDoors } from './three/geometry/doors.ts';
import { createMamlukMinaret } from './three/geometry/minaret.ts';
import { BAB_ZUWAYLA_ANNOTATIONS } from './three/geometry/annotations.ts';

export interface BabZuwaylaRemotionProps {
  frame?: number;
  durationInFrames?: number;
  historicalState?: ViewerState;
  cameraMode?: 'orthographic' | 'perspective';
  assemblyProgress?: number;
  explodedProgress?: number;
  showAnnotations?: boolean;
  width?: number;
  height?: number;
}

export const BabZuwaylaRemotion: React.FC<BabZuwaylaRemotionProps> = ({
  frame: propFrame,
  durationInFrames: propDuration,
  historicalState: propHistoricalState,
  cameraMode: propCameraMode,
  assemblyProgress: propAssemblyProgress,
  explodedProgress: propExplodedProgress,
  showAnnotations = false,
  width: propWidth,
  height: propHeight,
}) => {
  // Use Remotion deterministic frame context
  const remotionFrame = useCurrentFrame();
  const videoConfig = useVideoConfig();

  const currentFrame = propFrame !== undefined ? propFrame : remotionFrame;
  const totalFrames = propDuration !== undefined ? propDuration : videoConfig.durationInFrames;
  const canvasWidth = propWidth || videoConfig.width || 1920;
  const canvasHeight = propHeight || videoConfig.height || 1080;

  // Global progress (0.0 to 1.0)
  const progress = Math.min(1.0, Math.max(0.0, currentFrame / totalFrames));

  // Determine Choreography Act & Parameters
  // Frames 0-45:   Act 1 - Top orthographic plan
  // Frames 45-90:  Act 2 - Continuous transition to side elevation
  // Frames 90-135: Act 3 - Continuous transition to front elevation (1092 CE gate, no minarets)
  // Frames 135-190: Act 4 - Revealing later minarets (1415-1421 CE)
  // Frames 190-245: Act 5 - Controlled exploded view
  // Frames 245-300: Act 6 - Full reassembly & 3/4 perspective
  const act = useMemo(() => {
    if (propHistoricalState) {
      return {
        state: propHistoricalState,
        isOrtho: propCameraMode === 'orthographic',
        minaretsVisible: propHistoricalState !== 'FATIMID_ORIGINAL',
        explodeVal: propExplodedProgress !== undefined ? propExplodedProgress : 0,
        doorAngle: 35,
        minaretElevation: 0,
      };
    }

    if (progress < 0.15) {
      // Act 1: Top Plan (0 to 45f)
      return {
        state: 'TOP_PLAN' as ViewerState,
        isOrtho: true,
        minaretsVisible: false,
        explodeVal: 0,
        doorAngle: 35,
        minaretElevation: 0,
        camPos: new THREE.Vector3(0, 75, 0.01),
        lookAt: new THREE.Vector3(0, 0, 0),
        orthoZoom: 18,
      };
    } else if (progress < 0.30) {
      // Act 2: Transition to Side Elevation (45 to 90f)
      const t = (progress - 0.15) / (0.30 - 0.15);
      return {
        state: 'SIDE_ELEVATION' as ViewerState,
        isOrtho: true,
        minaretsVisible: false,
        explodeVal: 0,
        doorAngle: 35,
        minaretElevation: 0,
        camPos: new THREE.Vector3(
          interpolate(t, [0, 1], [0, -70]),
          interpolate(t, [0, 1], [75, 18]),
          interpolate(t, [0, 1], [0.01, 0])
        ),
        lookAt: new THREE.Vector3(0, interpolate(t, [0, 1], [0, 18]), 0),
        orthoZoom: interpolate(t, [0, 1], [18, 15]),
      };
    } else if (progress < 0.45) {
      // Act 3: Transition to Front Elevation 1092 CE (90 to 135f)
      const t = (progress - 0.30) / (0.45 - 0.30);
      return {
        state: 'FRONT_ELEVATION' as ViewerState,
        isOrtho: true,
        minaretsVisible: false,
        explodeVal: 0,
        doorAngle: 35,
        minaretElevation: 0,
        camPos: new THREE.Vector3(
          interpolate(t, [0, 1], [-70, 0]),
          interpolate(t, [0, 1], [18, 19]),
          interpolate(t, [0, 1], [0, 70])
        ),
        lookAt: new THREE.Vector3(0, 19, 0),
        orthoZoom: 14,
      };
    } else if (progress < 0.63) {
      // Act 4: Revealing Later Minarets (135 to 190f)
      const t = (progress - 0.45) / (0.63 - 0.45);
      const minaretElev = interpolate(t, [0, 0.85], [1.0, 0.0], {
        extrapolateLeft: 'clamp',
        extrapolateRight: 'clamp',
      });
      return {
        state: 'MAMLUK_ADDITIONS' as ViewerState,
        isOrtho: false,
        minaretsVisible: true,
        explodeVal: 0,
        doorAngle: 35,
        minaretElevation: minaretElev,
        camPos: new THREE.Vector3(
          interpolate(t, [0, 1], [0, 22]),
          interpolate(t, [0, 1], [19, 28]),
          interpolate(t, [0, 1], [70, 32])
        ),
        lookAt: new THREE.Vector3(0, 20, 0),
      };
    } else if (progress < 0.82) {
      // Act 5: Controlled Exploded View (190 to 245f)
      const t = (progress - 0.63) / (0.82 - 0.63);
      const explode = Math.sin(t * Math.PI) * 0.85;
      return {
        state: 'EXPLODED_VIEW' as ViewerState,
        isOrtho: false,
        minaretsVisible: true,
        explodeVal: explode,
        doorAngle: interpolate(t, [0, 0.5, 1], [35, 75, 35]),
        minaretElevation: 0,
        camPos: new THREE.Vector3(
          interpolate(t, [0, 1], [22, -34]),
          interpolate(t, [0, 1], [28, 24]),
          interpolate(t, [0, 1], [32, 38])
        ),
        lookAt: new THREE.Vector3(0, 18, 0),
      };
    } else {
      // Act 6: Full Reassembly & 3/4 Perspective (245 to 300f)
      const t = (progress - 0.82) / (1.0 - 0.82);
      return {
        state: 'FULLY_ASSEMBLED' as ViewerState,
        isOrtho: false,
        minaretsVisible: true,
        explodeVal: 0,
        doorAngle: 35,
        minaretElevation: 0,
        camPos: new THREE.Vector3(
          interpolate(t, [0, 1], [-34, -24]),
          interpolate(t, [0, 1], [24, 18]),
          interpolate(t, [0, 1], [38, 36])
        ),
        lookAt: new THREE.Vector3(0, 16, 0),
      };
    }
  }, [progress, propHistoricalState, propCameraMode, propExplodedProgress]);

  // Construct Architectural Model (cached once, transformed deterministically per frame)
  const { modelGroup, leftTower, rightTower, centralPortal, doors, leftMinaret, rightMinaret } =
    useMemo(() => {
      const materials = createMaterialPalette({
        stoneRoughness: 0.82,
        stoneWarmth: 0.55,
        wireframe: false,
        blueprintMode: false,
        shadowIntensity: 0.45,
        aoIntensity: 1.0,
      });

      const root = new THREE.Group();
      root.name = 'bab_zuwayla_remotion_root';

      const lt = createSemicircularTower(
        { side: 'left', radius: 5.6, height: 18.0, wallDepth: 8.0 },
        materials
      );
      lt.position.set(-7.4, 0, 0);
      root.add(lt);

      const rt = createSemicircularTower(
        { side: 'right', radius: 5.6, height: 18.0, wallDepth: 8.0 },
        materials
      );
      rt.position.set(7.4, 0, 0);
      root.add(rt);

      const cp = createCentralPortal(
        { passageWidth: 5.2, portalHeight: 8.6, passageDepth: 12.0, towerDistance: 14.8 },
        materials
      );
      root.add(cp);

      const dr = createGateDoors(5.2, 6.8, materials);
      root.add(dr.group);

      const lm = createMamlukMinaret({ side: 'left', baseY: 18.0 }, materials);
      lm.root.position.set(-7.4, 18.0, 0);
      root.add(lm.root);

      const rm = createMamlukMinaret({ side: 'right', baseY: 18.0 }, materials);
      rm.root.position.set(7.4, 18.0, 0);
      root.add(rm.root);

      // Cairo Ground Apron
      const groundGeom = new THREE.PlaneGeometry(90, 90);
      groundGeom.rotateX(-Math.PI / 2);
      const ground = new THREE.Mesh(groundGeom, materials.groundPaving);
      ground.position.y = -0.01;
      root.add(ground);

      return {
        modelGroup: root,
        leftTower: lt,
        rightTower: rt,
        centralPortal: cp,
        doors: dr,
        leftMinaret: lm,
        rightMinaret: rm,
      };
    }, []);

  // Apply frame transforms strictly deterministically
  const towerLateralShift = act.explodeVal * 5.5;
  leftTower.position.x = -7.4 - towerLateralShift;
  rightTower.position.x = 7.4 + towerLateralShift;

  const minaretY = 18.0 + act.explodeVal * 6.5 + (act.minaretElevation || 0) * 14.0;
  leftMinaret.root.position.x = leftTower.position.x;
  leftMinaret.root.position.y = minaretY;
  leftMinaret.root.visible = act.minaretsVisible;

  rightMinaret.root.position.x = rightTower.position.x;
  rightMinaret.root.position.y = minaretY;
  rightMinaret.root.visible = act.minaretsVisible;

  leftMinaret.setTierExplosion(act.explodeVal * 0.7);
  rightMinaret.setTierExplosion(act.explodeVal * 0.7);

  centralPortal.position.z = act.explodeVal * 3.5;
  doors.setDoorAngle(THREE.MathUtils.degToRad(act.doorAngle));

  // Determine Camera Parameters
  const cameraProps = useMemo(() => {
    const isOrtho = act.isOrtho;
    const aspect = canvasWidth / canvasHeight;
    const pos = act.camPos || new THREE.Vector3(-24, 18, 36);

    if (isOrtho) {
      const frustum = 42;
      return {
        orthographic: true,
        left: (-frustum * aspect) / 2,
        right: (frustum * aspect) / 2,
        top: frustum / 2,
        bottom: -frustum / 2,
        near: 0.1,
        far: 600,
        zoom: act.orthoZoom || 15,
        position: [pos.x, pos.y, pos.z] as [number, number, number],
      };
    } else {
      return {
        orthographic: false,
        fov: 40,
        aspect,
        near: 0.5,
        far: 400,
        position: [pos.x, pos.y, pos.z] as [number, number, number],
      };
    }
  }, [act, canvasWidth, canvasHeight]);

  return (
    <div
      style={{
        width: canvasWidth,
        height: canvasHeight,
        position: 'relative',
        backgroundColor: '#F3EBDB', // Approved RUWAQ Cream
        overflow: 'hidden',
      }}
    >
      <ThreeCanvas
        width={canvasWidth}
        height={canvasHeight}
        camera={cameraProps as any}
      >
        {/* Studio PBR Lighting */}
        <ambientLight intensity={0.4} color="#fbf7ed" />
        <directionalLight
          position={[24, 42, 28]}
          intensity={2.3}
          color="#fff2d4"
          castShadow
        />
        <hemisphereLight args={['#fbf7ed', '#8e8271', 1.05]} />
        <directionalLight position={[-30, 28, -25]} intensity={0.9} color="#e6dcce" />

        {/* Master Architectural Geometry */}
        <primitive object={modelGroup} />
      </ThreeCanvas>

      {/* Documentary Editorial Lower-Third (RUWAQ Clean Typography - No Interactive UI) */}
      <div
        style={{
          position: 'absolute',
          bottom: 50,
          left: 60,
          pointerEvents: 'none',
          fontFamily: 'Cinzel, serif',
          color: '#1C1B19',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span
            style={{
              fontSize: 14,
              letterSpacing: '0.25em',
              fontWeight: 'bold',
              color: '#A98A4B',
            }}
          >
            RUWAQ | رواق
          </span>
          <span style={{ color: '#A98A4B', opacity: 0.5 }}>•</span>
          <span style={{ fontSize: 13, fontFamily: 'monospace', color: '#1C1B19' }}>
            FRAME {currentFrame.toString().padStart(3, '0')} / {totalFrames}
          </span>
        </div>

        <h1
          style={{
            fontSize: 32,
            margin: '4px 0 0 0',
            fontWeight: 'bold',
            letterSpacing: '0.05em',
          }}
        >
          BAB ZUWAYLA
        </h1>

        <p
          style={{
            fontSize: 15,
            margin: '2px 0 0 0',
            fontFamily: 'monospace',
            color: '#8C4729',
            fontWeight: 500,
          }}
        >
          {act.state === 'FATIMID_ORIGINAL' && 'FATIMID FORTIFIED GATE (1092 CE / 485 AH)'}
          {act.state === 'TOP_PLAN' && 'TOP ORTHOGRAPHIC PLAN (PROPORTIONAL STUDY)'}
          {act.state === 'SIDE_ELEVATION' && 'SIDE ELEVATION (BASTION PROJECTION)'}
          {act.state === 'FRONT_ELEVATION' && 'FRONT ELEVATION • BADR AL-JAMALI'}
          {act.state === 'MAMLUK_ADDITIONS' && 'MAMLUK MINARETS ADDITION (1415–1421 CE)'}
          {act.state === 'EXPLODED_VIEW' && 'DECONSTRUCTED ARCHITECTURAL COMPONENTS'}
          {act.state === 'FULLY_ASSEMBLED' && 'FINAL ASSEMBLED MONUMENT'}
        </p>

        <p
          style={{
            fontSize: 11,
            margin: '4px 0 0 0',
            fontFamily: 'monospace',
            color: '#1C1B19',
            opacity: 0.7,
          }}
        >
          APPROXIMATE EDUCATIONAL RECONSTRUCTION • RUWAQ DOCUMENTARY SERIES
        </p>
      </div>
    </div>
  );
};
