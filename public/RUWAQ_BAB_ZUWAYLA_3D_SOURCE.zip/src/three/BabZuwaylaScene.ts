/**
 * Bab Zuwayla 3D Architectural Scene Engine
 * Adheres to Three.js PBR standards, dual camera projection, and external frame driver
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';

import {
  ViewerState,
  ComponentVisibility,
  MaterialSettings,
  AnnotationItem,
} from '../types.ts';
import {
  createMaterialPalette,
  updateMaterialsWithSettings,
  MaterialPalette,
} from './materials.ts';
import { createSemicircularTower } from './geometry/tower.ts';
import { createCentralPortal } from './geometry/portal.ts';
import { createGateDoors, GateDoorsResult } from './geometry/doors.ts';
import { createMamlukMinaret, MinaretTiers } from './geometry/minaret.ts';
import { BAB_ZUWAYLA_ANNOTATIONS } from './geometry/annotations.ts';

export interface SceneCallbacks {
  onSelectComponent?: (info: {
    id: string;
    nameEn: string;
    nameAr: string;
    descriptionEn?: string;
    descriptionAr?: string;
    era?: string;
    certainty?: string;
  } | null) => void;
  onSelectAnnotation?: (annotation: AnnotationItem | null) => void;
}

export class BabZuwaylaScene {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private animFrameId: number = 0;
  private isDisposed: boolean = false;
  private isSoftwareGl: boolean = false;

  // Cameras & Controls
  public perspectiveCamera: THREE.PerspectiveCamera;
  public orthographicCamera: THREE.OrthographicCamera;
  public activeCamera: THREE.Camera;
  public controls: OrbitControls;

  // Camera animation interpolation targets
  private camCurrentPos = new THREE.Vector3(0, 16, 36);
  private camTargetPos = new THREE.Vector3(0, 16, 36);
  private camCurrentLook = new THREE.Vector3(0, 14, 0);
  private camTargetLook = new THREE.Vector3(0, 14, 0);
  private targetOrthoZoom: number = 18;
  private currentOrthoZoom: number = 18;
  private cameraTransitionSpeed: number = 4.0; // damping factor

  // Materials & Geometry
  private materials: MaterialPalette;
  private modelRoot: THREE.Group;
  private leftTower: THREE.Group;
  private rightTower: THREE.Group;
  private centralPortal: THREE.Group;
  private doorsAssembly: GateDoorsResult;
  private leftMinaret: MinaretTiers;
  private rightMinaret: MinaretTiers;
  private groundApron: THREE.Mesh;
  private blueprintFloorGrid: THREE.Mesh;

  // Annotations in 3D
  private annotationGroup: THREE.Group;
  private annotationSprites: Map<string, THREE.Sprite> = new Map();

  // Raycasting & Interaction
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private callbacks: SceneCallbacks;

  // Active configuration
  public currentState: ViewerState = 'FULLY_ASSEMBLED';
  public explodedProgress: number = 0;
  public minaretElevation: number = 0;
  public towerSeparation: number = 0;
  public doorAngleDeg: number = 35;
  public minaretsVisible: boolean = true;
  private isUserInteracting: boolean = false;

  // Default component visibility
  public visibility: ComponentVisibility = {
    leftTower: true,
    rightTower: true,
    centralArch: true,
    gatePassage: true,
    leftDoor: true,
    rightDoor: true,
    leftMinaret: true,
    rightMinaret: true,
    crenellations: true,
    ground: true,
  };

  constructor(container: HTMLElement, callbacks: SceneCallbacks = {}) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Detect Software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize Three.js WebGLRenderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true, // For canvas snapshot / GLB / documentary export
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.appendChild(this.renderer.domElement);

    // 3. Scene & Studio PBR Environment
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#F3EBDB'); // RUWAQ Cream
    this.scene.fog = new THREE.FogExp2('#F3EBDB', 0.0075);

    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    pmremGenerator.dispose();

    // 4. Cameras & OrbitControls
    const aspect = this.container.clientWidth / this.container.clientHeight;
    this.perspectiveCamera = new THREE.PerspectiveCamera(40, aspect, 0.5, 400);
    this.perspectiveCamera.position.copy(this.camCurrentPos);

    const frustumSize = 42;
    this.orthographicCamera = new THREE.OrthographicCamera(
      (-frustumSize * aspect) / 2,
      (frustumSize * aspect) / 2,
      frustumSize / 2,
      -frustumSize / 2,
      0.1,
      600
    );
    this.orthographicCamera.zoom = this.currentOrthoZoom;
    this.orthographicCamera.position.copy(this.camCurrentPos);

    this.activeCamera = this.perspectiveCamera;

    this.controls = new OrbitControls(
      this.perspectiveCamera,
      this.renderer.domElement
    );
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.08;
    this.controls.maxPolarAngle = Math.PI / 2 + 0.02; // prevent going below ground
    this.controls.minDistance = 6;
    this.controls.maxDistance = 140;
    this.controls.target.copy(this.camCurrentLook);

    this.controls.addEventListener('start', () => {
      this.isUserInteracting = true;
    });

    // 5. Lighting Rig (Warm Key + Cool Sky/Ground Fill + Rim)
    this.setupLighting();

    // 6. Materials & Procedural Geometry
    const defaultMaterialSettings: MaterialSettings = {
      stoneRoughness: 0.82,
      stoneWarmth: 0.55,
      wireframe: false,
      blueprintMode: false,
      shadowIntensity: 0.45,
      aoIntensity: 1.0,
    };
    this.materials = createMaterialPalette(defaultMaterialSettings);

    // 7. Assemble Architectural Model
    this.modelRoot = new THREE.Group();
    this.modelRoot.name = 'bab_zuwayla_monument_root';

    // Left Bastion (West Tower) at x = -7.4
    this.leftTower = createSemicircularTower(
      { side: 'left', radius: 5.6, height: 18.0, wallDepth: 8.0 },
      this.materials
    );
    this.leftTower.position.set(-7.4, 0, 0);
    this.modelRoot.add(this.leftTower);

    // Right Bastion (East Tower) at x = +7.4
    this.rightTower = createSemicircularTower(
      { side: 'right', radius: 5.6, height: 18.0, wallDepth: 8.0 },
      this.materials
    );
    this.rightTower.position.set(7.4, 0, 0);
    this.modelRoot.add(this.rightTower);

    // Central Arch & Passage
    this.centralPortal = createCentralPortal(
      { passageWidth: 5.2, portalHeight: 8.6, passageDepth: 12.0, towerDistance: 14.8 },
      this.materials
    );
    this.centralPortal.position.set(0, 0, 0);
    this.modelRoot.add(this.centralPortal);

    // Fortified Studded Doors (Inside Central Archway)
    this.doorsAssembly = createGateDoors(5.2, 6.8, this.materials);
    this.modelRoot.add(this.doorsAssembly.group);

    // Left Minaret (West Tower Addition)
    this.leftMinaret = createMamlukMinaret({ side: 'left', baseY: 18.0 }, this.materials);
    this.leftMinaret.root.position.set(-7.4, 18.0, 0);
    this.modelRoot.add(this.leftMinaret.root);

    // Right Minaret (East Tower Addition)
    this.rightMinaret = createMamlukMinaret({ side: 'right', baseY: 18.0 }, this.materials);
    this.rightMinaret.root.position.set(7.4, 18.0, 0);
    this.modelRoot.add(this.rightMinaret.root);

    // Ground Paving / Historic Cairo Apron
    const groundGeom = new THREE.PlaneGeometry(90, 90);
    groundGeom.rotateX(-Math.PI / 2);
    this.groundApron = new THREE.Mesh(groundGeom, this.materials.groundPaving);
    this.groundApron.name = 'historic_cairo_ground_apron';
    this.groundApron.position.y = -0.01;
    this.groundApron.receiveShadow = true;
    this.modelRoot.add(this.groundApron);

    // Blueprint floor drafting grid overlay
    const gridGeom = new THREE.PlaneGeometry(60, 60);
    gridGeom.rotateX(-Math.PI / 2);
    this.blueprintFloorGrid = new THREE.Mesh(gridGeom, this.materials.blueprintGrid);
    this.blueprintFloorGrid.name = 'architectural_blueprint_grid';
    this.blueprintFloorGrid.position.y = 0.01;
    this.modelRoot.add(this.blueprintFloorGrid);

    this.scene.add(this.modelRoot);

    // 8. 3D Annotation Anchors
    this.annotationGroup = new THREE.Group();
    this.annotationGroup.name = 'documentary_annotations_layer';
    this.setupAnnotations();
    this.scene.add(this.annotationGroup);

    // 9. Resize & Event Listeners
    this.handleResize = this.handleResize.bind(this);
    this.handlePointerDown = this.handlePointerDown.bind(this);
    window.addEventListener('resize', this.handleResize);
    this.renderer.domElement.addEventListener('pointerdown', this.handlePointerDown);

    this.handleResize();

    // 10. Start Animation Loop
    this.tick = this.tick.bind(this);
    this.tick();
  }

  private setupLighting() {
    // Warm Key Light (representing Cairo late afternoon sun / golden hour)
    const keyLight = new THREE.DirectionalLight('#fff2d4', 2.3);
    keyLight.position.set(24, 42, 28);
    keyLight.castShadow = !this.isSoftwareGl;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.bias = -0.0003;
    keyLight.shadow.normalBias = 0.02;

    const d = 32;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 140;
    this.scene.add(keyLight);

    // Hemisphere Light (Warm gold from ground, cool slate from sky)
    const hemiLight = new THREE.HemisphereLight('#fbf7ed', '#8e8271', 1.05);
    this.scene.add(hemiLight);

    // Subtle Rim Light for silhouette separation against background
    const rimLight = new THREE.DirectionalLight('#e6dcce', 0.9);
    rimLight.position.set(-30, 28, -25);
    this.scene.add(rimLight);
  }

  private setupAnnotations() {
    BAB_ZUWAYLA_ANNOTATIONS.forEach((item) => {
      // Create sleek editorial hotspot badge via canvas sprite
      const canvas = document.createElement('canvas');
      canvas.width = 128;
      canvas.height = 128;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Outer gold circle
        ctx.strokeStyle = '#A98A4B';
        ctx.lineWidth = 6;
        ctx.fillStyle = '#1C1B19';
        ctx.beginPath();
        ctx.arc(64, 64, 52, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Inner gold core
        ctx.fillStyle = '#A98A4B';
        ctx.beginPath();
        ctx.arc(64, 64, 26, 0, Math.PI * 2);
        ctx.fill();

        // Center dot
        ctx.fillStyle = '#F3EBDB';
        ctx.beginPath();
        ctx.arc(64, 64, 10, 0, Math.PI * 2);
        ctx.fill();
      }

      const texture = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({
        map: texture,
        transparent: true,
        depthTest: false,
      });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.position.set(item.position[0], item.position[1], item.position[2]);
      sprite.scale.set(1.5, 1.5, 1.5);
      sprite.userData = { annotation: item };

      this.annotationSprites.set(item.id, sprite);
      this.annotationGroup.add(sprite);
    });
  }

  // Set camera view according to the 8 required states
  public setState(state: ViewerState) {
    this.currentState = state;
    this.isUserInteracting = false;

    // Reset temporary explosion if switching away
    if (state !== 'EXPLODED_VIEW') {
      this.setExplodedProgress(0);
    }

    switch (state) {
      case 'FATIMID_ORIGINAL':
        // Original Fatimid gate in 1092 CE (NO minarets)
        this.setMinaretsVisible(false);
        this.switchCameraMode('perspective');
        this.camTargetPos.set(0, 10, 36);
        this.camTargetLook.set(0, 9, 0);
        this.setDoorAngle(35);
        break;

      case 'TOP_PLAN':
        // Orthographic plan view looking from above
        this.setMinaretsVisible(true);
        this.switchCameraMode('orthographic');
        this.targetOrthoZoom = 18;
        this.camTargetPos.set(0, 75, 0.01);
        this.camTargetLook.set(0, 0, 0);
        this.activeCamera.up.set(0, 0, -1); // North points up
        break;

      case 'SIDE_ELEVATION':
        // Orthographic side elevation view
        this.setMinaretsVisible(true);
        this.switchCameraMode('orthographic');
        this.targetOrthoZoom = 15;
        this.camTargetPos.set(-70, 18, 0);
        this.camTargetLook.set(0, 18, 0);
        this.activeCamera.up.set(0, 1, 0);
        break;

      case 'FRONT_ELEVATION':
        // Orthographic front elevation view
        this.setMinaretsVisible(true);
        this.switchCameraMode('orthographic');
        this.targetOrthoZoom = 14;
        this.camTargetPos.set(0, 19, 70);
        this.camTargetLook.set(0, 19, 0);
        this.activeCamera.up.set(0, 1, 0);
        break;

      case 'PERSPECTIVE_3Q':
        // Three-quarter documentary camera angle
        this.setMinaretsVisible(true);
        this.switchCameraMode('perspective');
        this.camTargetPos.set(-28, 17, 34);
        this.camTargetLook.set(0, 16, 0);
        break;

      case 'MAMLUK_ADDITIONS':
        // Highlighting the 1415–1421 CE minaret additions
        this.setMinaretsVisible(true);
        this.switchCameraMode('perspective');
        this.camTargetPos.set(22, 28, 30);
        this.camTargetLook.set(0, 22, 0);
        this.setMinaretElevation(0);
        break;

      case 'EXPLODED_VIEW':
        // Separated architectural components
        this.setMinaretsVisible(true);
        this.switchCameraMode('perspective');
        this.camTargetPos.set(-34, 24, 38);
        this.camTargetLook.set(0, 18, 0);
        this.setExplodedProgress(0.75);
        this.setDoorAngle(70);
        break;

      case 'FULLY_ASSEMBLED':
      default:
        this.setMinaretsVisible(true);
        this.switchCameraMode('perspective');
        this.camTargetPos.set(-24, 18, 36);
        this.camTargetLook.set(0, 16, 0);
        this.setExplodedProgress(0);
        this.setDoorAngle(35);
        break;
    }
  }

  public switchCameraMode(mode: 'perspective' | 'orthographic') {
    const isOrtho = mode === 'orthographic';
    const oldCam = this.activeCamera;
    const newCam = isOrtho ? this.orthographicCamera : this.perspectiveCamera;

    if (oldCam !== newCam) {
      newCam.position.copy(oldCam.position);
      this.activeCamera = newCam;
      this.controls.object = newCam;
      this.controls.update();
    }
  }

  /**
   * Continuous animation driver for Remotion & timeline scrubber
   * @param frame Current frame (0 to totalFrames)
   * @param totalFrames Total sequence frames (e.g., 300)
   */
  public seekFrame(frame: number, totalFrames = 300) {
    const progress = Math.min(1.0, Math.max(0.0, frame / totalFrames));

    // Remotion Documentary Choreography timeline across 6 sequence acts:
    // Act 1 (0.00 - 0.18): Top Orthographic Plan
    // Act 2 (0.18 - 0.35): Side Orthographic Elevation
    // Act 3 (0.35 - 0.52): Front Orthographic Elevation (Fatimid 1092 CE gate)
    // Act 4 (0.52 - 0.68): Mamluk Minarets Added (1415–1421 CE)
    // Act 5 (0.68 - 0.85): Exploded View (Architectural Deconstruction)
    // Act 6 (0.85 - 1.00): Fully Assembled Perspective Cinematic View

    if (progress < 0.18) {
      // Act 1: Top Plan
      this.currentState = 'TOP_PLAN';
      this.switchCameraMode('orthographic');
      this.setMinaretsVisible(false);
      this.setExplodedProgress(0);

      this.camTargetPos.set(0, 75, 0.01);
      this.camTargetLook.set(0, 0, 0);
      this.targetOrthoZoom = 18;
    } else if (progress < 0.35) {
      // Act 2: Side Elevation
      this.currentState = 'SIDE_ELEVATION';
      this.switchCameraMode('orthographic');
      this.setMinaretsVisible(false);
      this.setExplodedProgress(0);

      const t = (progress - 0.18) / (0.35 - 0.18);
      this.camTargetPos.lerpVectors(
        new THREE.Vector3(0, 75, 0.01),
        new THREE.Vector3(-70, 18, 0),
        t
      );
      this.camTargetLook.lerpVectors(
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 18, 0),
        t
      );
      this.targetOrthoZoom = 15;
    } else if (progress < 0.52) {
      // Act 3: Front Elevation (Fatimid Original 1092 CE)
      this.currentState = 'FRONT_ELEVATION';
      this.switchCameraMode('orthographic');
      this.setMinaretsVisible(false);
      this.setExplodedProgress(0);

      const t = (progress - 0.35) / (0.52 - 0.35);
      this.camTargetPos.lerpVectors(
        new THREE.Vector3(-70, 18, 0),
        new THREE.Vector3(0, 19, 70),
        t
      );
      this.camTargetLook.set(0, 19, 0);
      this.targetOrthoZoom = 14;
    } else if (progress < 0.68) {
      // Act 4: Mamluk Minarets Addition (1415–1421 CE)
      this.currentState = 'MAMLUK_ADDITIONS';
      this.switchCameraMode('perspective');
      this.setMinaretsVisible(true);

      const t = (progress - 0.52) / (0.68 - 0.52);
      // Minarets descend smoothly into place
      const elev = (1.0 - t) * 14.0;
      this.setMinaretElevation(elev / 14.0);

      this.camTargetPos.lerpVectors(
        new THREE.Vector3(0, 19, 65),
        new THREE.Vector3(22, 28, 32),
        t
      );
      this.camTargetLook.set(0, 20, 0);
    } else if (progress < 0.85) {
      // Act 5: Exploded Architectural Components
      this.currentState = 'EXPLODED_VIEW';
      this.switchCameraMode('perspective');
      this.setMinaretsVisible(true);

      const t = (progress - 0.68) / (0.85 - 0.68);
      // Smooth bell curve explosion
      const explodeVal = Math.sin(t * Math.PI) * 0.85;
      this.setExplodedProgress(explodeVal);

      this.camTargetPos.lerpVectors(
        new THREE.Vector3(22, 28, 32),
        new THREE.Vector3(-34, 24, 38),
        t
      );
      this.camTargetLook.set(0, 18, 0);
    } else {
      // Act 6: Fully Assembled Grand Documentary Final View
      this.currentState = 'FULLY_ASSEMBLED';
      this.switchCameraMode('perspective');
      this.setMinaretsVisible(true);
      this.setExplodedProgress(0);

      const t = (progress - 0.85) / (1.0 - 0.85);
      this.camTargetPos.lerpVectors(
        new THREE.Vector3(-34, 24, 38),
        new THREE.Vector3(-24, 18, 36),
        t
      );
      this.camTargetLook.set(0, 16, 0);
    }
  }

  // Adjust exploded-view progress (0 = assembled, 1 = maximum deconstruction)
  public setExplodedProgress(val: number) {
    this.explodedProgress = THREE.MathUtils.clamp(val, 0, 1);

    // Lateral separation of the two semicircular towers along X
    const towerLateralShift = this.explodedProgress * 5.5;
    this.leftTower.position.x = -7.4 - towerLateralShift;
    this.rightTower.position.x = 7.4 + towerLateralShift;

    // Shift minarets with the towers + vertical separation
    const minaretExtraY = this.explodedProgress * 6.5;
    this.leftMinaret.root.position.x = this.leftTower.position.x;
    this.leftMinaret.root.position.y = 18.0 + minaretExtraY + this.minaretElevation * 12.0;

    this.rightMinaret.root.position.x = this.rightTower.position.x;
    this.rightMinaret.root.position.y = 18.0 + minaretExtraY + this.minaretElevation * 12.0;

    // Separate minaret tiers vertically
    this.leftMinaret.setTierExplosion(this.explodedProgress * 0.7);
    this.rightMinaret.setTierExplosion(this.explodedProgress * 0.7);

    // Frontwards separation of central entrance arch
    this.centralPortal.position.z = this.explodedProgress * 3.5;
  }

  public setMinaretElevation(val: number) {
    this.minaretElevation = THREE.MathUtils.clamp(val, 0, 1);
    const elev = this.minaretElevation * 12.0;
    this.leftMinaret.root.position.y = 18.0 + elev + this.explodedProgress * 6.5;
    this.rightMinaret.root.position.y = 18.0 + elev + this.explodedProgress * 6.5;
  }

  public setTowerSeparation(val: number) {
    this.towerSeparation = THREE.MathUtils.clamp(val, 0, 1);
    const shift = this.towerSeparation * 6.0;
    this.leftTower.position.x = -7.4 - shift;
    this.rightTower.position.x = 7.4 + shift;
    this.leftMinaret.root.position.x = this.leftTower.position.x;
    this.rightMinaret.root.position.x = this.rightTower.position.x;
  }

  public setDoorAngle(angleDeg: number) {
    this.doorAngleDeg = THREE.MathUtils.clamp(angleDeg, 0, 90);
    this.doorsAssembly.setDoorAngle(THREE.MathUtils.degToRad(this.doorAngleDeg));
  }

  public setMinaretsVisible(visible: boolean) {
    this.minaretsVisible = visible;
    this.leftMinaret.root.visible = visible && this.visibility.leftMinaret;
    this.rightMinaret.root.visible = visible && this.visibility.rightMinaret;
  }

  // Fine-Grained Component Positioning Controls
  public setLeftTowerOffset(dx: number, dy: number, dz: number) {
    this.leftTower.position.set(-7.4 + dx, dy, dz);
    this.leftMinaret.root.position.x = this.leftTower.position.x;
  }

  public setRightTowerOffset(dx: number, dy: number, dz: number) {
    this.rightTower.position.set(7.4 + dx, dy, dz);
    this.rightMinaret.root.position.x = this.rightTower.position.x;
  }

  public setCentralPortalOffset(dx: number, dy: number, dz: number) {
    this.centralPortal.position.set(dx, dy, dz);
  }

  public setLeftMinaretOffset(dy: number) {
    this.leftMinaret.root.position.y = 18.0 + dy;
  }

  public setRightMinaretOffset(dy: number) {
    this.rightMinaret.root.position.y = 18.0 + dy;
  }

  public setIndividualDoorAngles(leftDeg: number, rightDeg: number) {
    this.doorsAssembly.leftPivot.rotation.y = -THREE.MathUtils.degToRad(leftDeg);
    this.doorsAssembly.rightPivot.rotation.y = THREE.MathUtils.degToRad(rightDeg);
  }

  public setMinaretTierSeparation(progress: number) {
    this.leftMinaret.setTierExplosion(progress);
    this.rightMinaret.setTierExplosion(progress);
  }

  public setComponentVisibility(vis: Partial<ComponentVisibility>) {
    this.visibility = { ...this.visibility, ...vis };
    this.leftTower.visible = this.visibility.leftTower;
    this.rightTower.visible = this.visibility.rightTower;
    this.centralPortal.visible = this.visibility.centralArch;
    this.doorsAssembly.leftPivot.visible = this.visibility.leftDoor;
    this.doorsAssembly.rightPivot.visible = this.visibility.rightDoor;
    this.leftMinaret.root.visible = this.minaretsVisible && this.visibility.leftMinaret;
    this.rightMinaret.root.visible = this.minaretsVisible && this.visibility.rightMinaret;
    this.groundApron.visible = this.visibility.ground;

    // Toggle crenellations
    const leftCrenel = this.leftTower.getObjectByName('left_tower_crenellations');
    const rightCrenel = this.rightTower.getObjectByName('right_tower_crenellations');
    const centralCrenel = this.centralPortal.getObjectByName('central_curtain_parapet');
    if (leftCrenel) leftCrenel.visible = this.visibility.crenellations;
    if (rightCrenel) rightCrenel.visible = this.visibility.crenellations;
    if (centralCrenel) centralCrenel.visible = this.visibility.crenellations;
  }

  public setMaterialSettings(settings: MaterialSettings) {
    updateMaterialsWithSettings(this.materials, settings);
  }

  public setAnnotationsVisible(visible: boolean) {
    this.annotationGroup.visible = visible;
  }

  // Handle Raycasting Pointer Down for 3D selection
  private handlePointerDown(e: MouseEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.activeCamera);

    // First check annotation sprites
    const spriteHits = this.raycaster.intersectObjects(
      this.annotationGroup.children,
      false
    );
    if (spriteHits.length > 0) {
      const hitSprite = spriteHits[0].object as THREE.Sprite;
      const annotation = hitSprite.userData?.annotation as AnnotationItem;
      if (annotation && this.callbacks.onSelectAnnotation) {
        this.callbacks.onSelectAnnotation(annotation);
        return;
      }
    }

    // Next check architectural model parts
    const hits = this.raycaster.intersectObjects(this.modelRoot.children, true);
    if (hits.length > 0) {
      let currentObj: THREE.Object3D | null = hits[0].object;
      while (currentObj && currentObj !== this.modelRoot) {
        if (currentObj.userData && currentObj.userData.nameEn) {
          if (this.callbacks.onSelectComponent) {
            this.callbacks.onSelectComponent({
              id: currentObj.userData.id || currentObj.name,
              nameEn: currentObj.userData.nameEn,
              nameAr: currentObj.userData.nameAr || '',
              descriptionEn: currentObj.userData.descriptionEn || currentObj.userData.description,
              descriptionAr: currentObj.userData.descriptionAr,
              era: currentObj.userData.era,
              certainty: currentObj.userData.certainty,
            });
          }
          return;
        }
        currentObj = currentObj.parent;
      }
    }

    // Clicked background void -> clear selection
    if (this.callbacks.onSelectComponent) {
      this.callbacks.onSelectComponent(null);
    }
  }

  /**
   * Export fully named 3D model hierarchy to GLB file
   */
  public exportGLB() {
    const exporter = new GLTFExporter();
    exporter.parse(
      this.modelRoot,
      (gltf) => {
        const output = gltf instanceof ArrayBuffer ? gltf : JSON.stringify(gltf, null, 2);
        const blob = new Blob([output], {
          type: gltf instanceof ArrayBuffer ? 'application/octet-stream' : 'application/json',
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `bab_zuwayla_ruwaq_reconstruction_${Date.now()}.glb`;
        link.click();
        URL.revokeObjectURL(url);
      },
      (error) => {
        console.error('An error occurred during GLB export:', error);
      },
      { binary: true }
    );
  }

  /**
   * Capture high-res snapshot of current view
   */
  public captureSnapshot(): string {
    this.renderer.render(this.scene, this.activeCamera);
    return this.renderer.domElement.toDataURL('image/png');
  }

  private handleResize() {
    if (!this.container || this.isDisposed) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width === 0 || height === 0) return;

    const aspect = width / height;

    // Perspective
    this.perspectiveCamera.aspect = aspect;
    this.perspectiveCamera.updateProjectionMatrix();

    // Orthographic
    const frustumSize = 42;
    this.orthographicCamera.left = (-frustumSize * aspect) / 2;
    this.orthographicCamera.right = (frustumSize * aspect) / 2;
    this.orthographicCamera.top = frustumSize / 2;
    this.orthographicCamera.bottom = -frustumSize / 2;
    this.orthographicCamera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
  }

  // Animation render loop
  private tick() {
    if (this.isDisposed) return;

    // Smooth exponential damping camera transitions when not manually orbiting
    if (!this.isUserInteracting) {
      const delta = 0.045;
      const k = this.cameraTransitionSpeed;
      const factor = 1.0 - Math.exp(-k * delta);

      this.activeCamera.position.lerp(this.camTargetPos, factor);
      this.controls.target.lerp(this.camTargetLook, factor);

      if (this.activeCamera === this.orthographicCamera) {
        this.currentOrthoZoom += (this.targetOrthoZoom - this.currentOrthoZoom) * factor;
        this.orthographicCamera.zoom = this.currentOrthoZoom;
        this.orthographicCamera.updateProjectionMatrix();
      }
    }

    this.controls.update();
    this.renderer.render(this.scene, this.activeCamera);

    this.animFrameId = requestAnimationFrame(this.tick);
  }

  public dispose() {
    this.isDisposed = true;
    cancelAnimationFrame(this.animFrameId);
    window.removeEventListener('resize', this.handleResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.handlePointerDown);

    this.controls.dispose();
    this.renderer.dispose();

    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
