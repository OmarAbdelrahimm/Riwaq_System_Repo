/**
 * Central Entrance Arch & Gate Passage Geometry
 * Fatimid Era (1092 CE / 485 AH) - Vizier Badr al-Jamali
 */

import * as THREE from 'three';
import { MaterialPalette } from '../materials.ts';

export interface PortalOptions {
  passageWidth?: number;
  portalHeight?: number;
  passageDepth?: number;
  towerDistance?: number;
}

export function createCentralPortal(
  options: PortalOptions,
  materials: MaterialPalette
): THREE.Group {
  const {
    passageWidth = 5.2,
    portalHeight = 8.6,
    passageDepth = 12.0,
    towerDistance = 14.8,
  } = options;

  const portalGroup = new THREE.Group();
  portalGroup.name = 'central_entrance_arch';
  portalGroup.userData = {
    id: 'central_portal',
    nameEn: 'Central Entrance Portal & Gate Passage',
    nameAr: 'المدخل الأوسط وممر البوابة الفاطمية',
    era: 'Fatimid (1092 CE / 485 AH)',
    patron: 'Badr al-Jamali (أمير الجيوش بدر الجمالي)',
    descriptionEn:
      'Fortified portal featuring a slightly pointed arch with joggled cushion voussoirs, leading into a cross-vaulted defensive vestibule with murder holes.',
    descriptionAr:
      'عقد المدخل المدبب المزين بكتل الوسائد الصنجية المنحوتة، يفتح على ممر دفاعي مقبى مزود بسقاطات دفاعية لإلقاء المواد الحارقة.',
    certainty: 'Historical Record & Archaeological In Situ',
  };

  // 1. Archway Jamb Piers (Left and Right of the opening)
  const pierWidth = (towerDistance - passageWidth) / 2;
  const jambDepth = 3.6;
  const pierHeight = portalHeight * 0.65;

  // Left pier
  const leftPierGeom = new THREE.BoxGeometry(pierWidth, pierHeight, jambDepth);
  const leftPier = new THREE.Mesh(leftPierGeom, materials.fatimidStone);
  leftPier.name = 'left_arch_jamb_pier';
  leftPier.position.set(-passageWidth / 2 - pierWidth / 2, pierHeight / 2, 0);
  leftPier.castShadow = true;
  leftPier.receiveShadow = true;
  portalGroup.add(leftPier);

  // Right pier
  const rightPierGeom = new THREE.BoxGeometry(pierWidth, pierHeight, jambDepth);
  const rightPier = new THREE.Mesh(rightPierGeom, materials.fatimidStone);
  rightPier.name = 'right_arch_jamb_pier';
  rightPier.position.set(passageWidth / 2 + pierWidth / 2, pierHeight / 2, 0);
  rightPier.castShadow = true;
  rightPier.receiveShadow = true;
  portalGroup.add(rightPier);

  // Impost capital moldings atop piers
  const impostGeom = new THREE.BoxGeometry(0.7, 0.35, jambDepth + 0.3);
  const leftImpost = new THREE.Mesh(impostGeom, materials.fatimidDarkStone);
  leftImpost.position.set(-passageWidth / 2, pierHeight + 0.175, 0);
  leftImpost.castShadow = true;
  portalGroup.add(leftImpost);

  const rightImpost = new THREE.Mesh(impostGeom, materials.fatimidDarkStone);
  rightImpost.position.set(passageWidth / 2, pierHeight + 0.175, 0);
  rightImpost.castShadow = true;
  portalGroup.add(rightImpost);

  // 2. Pointed Arch Ring with Cushion Voussoirs (Iconic Fatimid Architectural Signature)
  const archRingGroup = new THREE.Group();
  archRingGroup.name = 'pointed_arch_cushion_voussoirs';
  archRingGroup.userData = {
    nameEn: 'Fatimid Cushion Voussoirs (الصنجات الوسادية)',
    nameAr: 'الصنجات الوسادية ذات الواجهات المحدبة',
    description: 'Iconic cushion voussoirs introduced to Cairo during the Fatimid fortification of 1092 CE.',
  };

  const voussoirCount = 17;
  const archRadius = passageWidth / 2;
  const archCenterY = pierHeight + 0.35;
  const voussoirDepth = jambDepth;
  const voussoirThickness = 1.05;

  for (let v = 0; v < voussoirCount; v++) {
    const angleFraction = (v + 0.5) / voussoirCount;
    const angle = Math.PI - angleFraction * Math.PI;

    // Cushion voussoir block with subtle convex rounded pillow front
    const vWidth = (Math.PI * archRadius) / voussoirCount * 0.94;
    const vGeom = new THREE.BoxGeometry(vWidth, voussoirThickness, voussoirDepth);
    const vMesh = new THREE.Mesh(vGeom, materials.fatimidStone);

    // Position along arch arc
    const rMid = archRadius + voussoirThickness / 2;
    vMesh.position.set(
      Math.cos(angle) * rMid,
      archCenterY + Math.sin(angle) * rMid * 1.08, // slightly pointed vertical elongation
      0
    );
    vMesh.rotation.z = angle - Math.PI / 2;
    vMesh.castShadow = true;
    vMesh.receiveShadow = true;
    vMesh.name = `voussoir_${v}`;
    archRingGroup.add(vMesh);
  }
  portalGroup.add(archRingGroup);

  // Tympanum / Arch Spandrel Masonry above the arch
  const spandrelHeight = 4.2;
  const spandrelGeom = new THREE.BoxGeometry(towerDistance, spandrelHeight, jambDepth);
  const spandrelMesh = new THREE.Mesh(spandrelGeom, materials.fatimidStone);
  spandrelMesh.name = 'arch_spandrel_masonry';
  spandrelMesh.position.set(0, portalHeight + spandrelHeight / 2 - 0.2, 0);
  spandrelMesh.castShadow = true;
  spandrelMesh.receiveShadow = true;
  portalGroup.add(spandrelMesh);

  // 3. Arched Machicolation Gallery / Upper Bridge Arch
  // (Visible in image_8d20f9e3.png - the open arch high above the portal that connects the two towers)
  const upperArchGroup = new THREE.Group();
  upperArchGroup.name = 'upper_machicolation_gallery_arch';
  upperArchGroup.userData = {
    nameEn: 'Upper Machicolation Bridge Arch',
    nameAr: 'العقد العلوي لسقاطة الدفاع بين البرجين',
    description: 'Arched bridge linking the twin towers above the portal with defensive machicolation slits.',
  };

  const upperArchY = 12.8;
  const upperArchSpan = passageWidth + 0.8;
  const upperArchDepth = 2.4;

  // Upper arch surround lintel / opening
  const upperLeftPillarGeom = new THREE.BoxGeometry(1.4, 3.8, upperArchDepth);
  const upperLeftPillar = new THREE.Mesh(upperLeftPillarGeom, materials.fatimidStone);
  upperLeftPillar.position.set(-upperArchSpan / 2 - 0.7, upperArchY + 1.9, -1.2);
  upperLeftPillar.castShadow = true;
  upperArchGroup.add(upperLeftPillar);

  const upperRightPillarGeom = new THREE.BoxGeometry(1.4, 3.8, upperArchDepth);
  const upperRightPillar = new THREE.Mesh(upperRightPillarGeom, materials.fatimidStone);
  upperRightPillar.position.set(upperArchSpan / 2 + 0.7, upperArchY + 1.9, -1.2);
  upperRightPillar.castShadow = true;
  upperArchGroup.add(upperRightPillar);

  // Upper arch curve
  const upperArchGeom = new THREE.CylinderGeometry(
    upperArchSpan / 2 + 0.6,
    upperArchSpan / 2 + 0.6,
    upperArchDepth,
    24,
    1,
    true,
    0,
    Math.PI
  );
  upperArchGeom.rotateZ(Math.PI / 2);
  upperArchGeom.rotateY(Math.PI / 2);
  const upperArchCurve = new THREE.Mesh(upperArchGeom, materials.fatimidDarkStone);
  upperArchCurve.position.set(0, upperArchY + 3.2, -1.2);
  upperArchCurve.castShadow = true;
  upperArchGroup.add(upperArchCurve);

  portalGroup.add(upperArchGroup);

  // 4. Central Parapet & Battlements between Towers
  const parapetY = 17.6;
  const parapetGeom = new THREE.BoxGeometry(towerDistance - 1.2, 0.7, 1.8);
  const parapetMesh = new THREE.Mesh(parapetGeom, materials.fatimidDarkStone);
  parapetMesh.name = 'central_curtain_parapet';
  parapetMesh.position.set(0, parapetY, -1.2);
  parapetMesh.castShadow = true;
  portalGroup.add(parapetMesh);

  // Central stepped merlons
  const centralMerlonCount = 7;
  const cMerlonWidth = 0.8;
  const cMerlonHeight = 1.35;
  const cSpacing = (towerDistance - 2.4) / centralMerlonCount;

  for (let cm = 0; cm < centralMerlonCount; cm++) {
    const cmX = -((towerDistance - 2.4) / 2) + (cm + 0.5) * cSpacing;
    const cMerlon = new THREE.Group();
    const cmBase = new THREE.Mesh(
      new THREE.BoxGeometry(cMerlonWidth, cMerlonHeight * 0.7, 0.5),
      materials.fatimidStone
    );
    cmBase.position.y = (cMerlonHeight * 0.7) / 2;
    cmBase.castShadow = true;
    cMerlon.add(cmBase);

    const cmCap = new THREE.Mesh(
      new THREE.CylinderGeometry(cMerlonWidth * 0.45, cMerlonWidth * 0.45, 0.5, 12, 1, false, 0, Math.PI),
      materials.fatimidStone
    );
    cmCap.rotateZ(Math.PI / 2);
    cmCap.rotateY(Math.PI / 2);
    cmCap.position.y = cMerlonHeight * 0.7;
    cmCap.castShadow = true;
    cMerlon.add(cmCap);

    cMerlon.position.set(cmX, parapetY + 0.35, -1.2);
    cMerlon.name = `central_merlon_${cm}`;
    portalGroup.add(cMerlon);
  }

  // 5. Gate Passage Vault (Connecting through the city wall into Cairo)
  const passageGroup = new THREE.Group();
  passageGroup.name = 'gate_passage_vault';
  passageGroup.userData = {
    id: 'passage_vault',
    nameEn: 'Fortified Gate Passage & Vault',
    nameAr: 'ممر البوابة المقبى',
    descriptionEn: 'Deep vaulted tunnel connecting the outer southern approach to al-Mu\'izz street inside Cairo.',
    descriptionAr: 'الممر المقبى العميق الممتد من البوابة الجنوبية إلى شارع المعز لدين الله الفاطمي.',
  };

  // Passage floor
  const passageFloorGeom = new THREE.BoxGeometry(passageWidth, 0.25, passageDepth);
  const passageFloor = new THREE.Mesh(passageFloorGeom, materials.fatimidDarkStone);
  passageFloor.position.set(0, 0.125, -passageDepth / 2);
  passageFloor.receiveShadow = true;
  passageGroup.add(passageFloor);

  // Vaulted ceiling
  const vaultRadius = passageWidth / 2;
  const vaultGeom = new THREE.CylinderGeometry(
    vaultRadius,
    vaultRadius,
    passageDepth,
    24,
    1,
    true,
    0,
    Math.PI
  );
  vaultGeom.rotateZ(Math.PI / 2);
  const vaultMesh = new THREE.Mesh(vaultGeom, materials.fatimidDarkStone);
  vaultMesh.position.set(0, pierHeight, -passageDepth / 2);
  vaultMesh.scale.set(1, 1.15, 1);
  vaultMesh.castShadow = true;
  passageGroup.add(vaultMesh);

  portalGroup.add(passageGroup);

  return portalGroup;
}
