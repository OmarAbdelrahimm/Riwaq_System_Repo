/**
 * Semicircular Stone Tower Geometry (Left / Right Bastions)
 * Fatimid Era (1092 CE / 485 AH) - Vizier Badr al-Jamali
 */

import * as THREE from 'three';
import { MaterialPalette } from '../materials.ts';

export interface TowerOptions {
  side: 'left' | 'right';
  radius?: number;
  height?: number;
  wallDepth?: number;
}

/**
 * Builds an authentic Fatimid semicircular bastion tower as a composite THREE.Group
 */
export function createSemicircularTower(
  options: TowerOptions,
  materials: MaterialPalette
): THREE.Group {
  const {
    side,
    radius = 5.6,
    height = 18.0,
    wallDepth = 8.0,
  } = options;

  const towerGroup = new THREE.Group();
  const namePrefix = side === 'left' ? 'left' : 'right';
  towerGroup.name = `${namePrefix}_semicircular_tower`;
  towerGroup.userData = {
    id: `${namePrefix}_tower`,
    nameEn: `${side === 'left' ? 'West (Left)' : 'East (Right)'} Semicircular Tower`,
    nameAr: side === 'left' ? 'البرج الغربي (الأيسر)' : 'البرج الشرقي (الأيمن)',
    era: 'Fatimid (1092 CE / 485 AH)',
    patron: 'Badr al-Jamali (أمير الجيوش بدر الجمالي)',
    descriptionEn:
      'Massive solid dressed limestone semicircular bastion designed to deflect siege catapult projectiles and enfilade attackers.',
    descriptionAr:
      'برج حجري نصف دائري ضخم من الحجر الفص الجيري المصقول، صُمم لحماية مدخل القاهرة وتشتيت مقذوفات الحصار.',
    certainty: 'Historical Record & Archaeological In Situ',
  };

  // 1. Foundation Plinth / Battered Base Course
  const plinthHeight = 1.4;
  const plinthRadius = radius + 0.35;
  const plinthGeom = new THREE.CylinderGeometry(
    radius,
    plinthRadius,
    plinthHeight,
    28,
    1,
    false,
    0,
    Math.PI
  );
  // Rotate so flat side faces north (towards Cairo interior)
  plinthGeom.rotateY(Math.PI / 2);
  const plinthMesh = new THREE.Mesh(plinthGeom, materials.fatimidDarkStone);
  plinthMesh.name = `${namePrefix}_tower_foundation_plinth`;
  plinthMesh.position.set(0, plinthHeight / 2, 0);
  plinthMesh.castShadow = true;
  plinthMesh.receiveShadow = true;
  towerGroup.add(plinthMesh);

  // Plinth back rectangular masonry
  const plinthBackGeom = new THREE.BoxGeometry(plinthRadius * 2, plinthHeight, wallDepth);
  const plinthBackMesh = new THREE.Mesh(plinthBackGeom, materials.fatimidDarkStone);
  plinthBackMesh.name = `${namePrefix}_tower_foundation_back`;
  plinthBackMesh.position.set(0, plinthHeight / 2, -wallDepth / 2);
  plinthBackMesh.castShadow = true;
  plinthBackMesh.receiveShadow = true;
  towerGroup.add(plinthBackMesh);

  // 2. Primary Semicircular Bastion Shaft
  const shaftHeight = height - plinthHeight - 1.8;
  const shaftGeom = new THREE.CylinderGeometry(
    radius,
    radius,
    shaftHeight,
    32,
    8,
    false,
    0,
    Math.PI
  );
  shaftGeom.rotateY(Math.PI / 2);
  const shaftMesh = new THREE.Mesh(shaftGeom, materials.fatimidStone);
  shaftMesh.name = `${namePrefix}_tower_shaft`;
  shaftMesh.position.set(0, plinthHeight + shaftHeight / 2, 0);
  shaftMesh.castShadow = true;
  shaftMesh.receiveShadow = true;
  towerGroup.add(shaftMesh);

  // Back wall masonry linking into city fortification
  const backWallGeom = new THREE.BoxGeometry(radius * 2, shaftHeight, wallDepth);
  const backWallMesh = new THREE.Mesh(backWallGeom, materials.fatimidStone);
  backWallMesh.name = `${namePrefix}_tower_rear_wall`;
  backWallMesh.position.set(0, plinthHeight + shaftHeight / 2, -wallDepth / 2);
  backWallMesh.castShadow = true;
  backWallMesh.receiveShadow = true;
  towerGroup.add(backWallMesh);

  // 3. Horizontal Stringcourse / Torus Molding
  const moldingHeight = 0.45;
  const moldingRadius = radius + 0.22;
  const moldingGeom = new THREE.CylinderGeometry(
    moldingRadius,
    moldingRadius,
    moldingHeight,
    32,
    1,
    false,
    0,
    Math.PI
  );
  moldingGeom.rotateY(Math.PI / 2);
  const moldingMesh = new THREE.Mesh(moldingGeom, materials.fatimidDarkStone);
  moldingMesh.name = `${namePrefix}_tower_stringcourse`;
  moldingMesh.position.set(0, plinthHeight + shaftHeight * 0.65, 0);
  moldingMesh.castShadow = true;
  towerGroup.add(moldingMesh);

  // 4. Arrow Slit Embrasures (Loop-holes for archers)
  const slitGroup = new THREE.Group();
  slitGroup.name = `${namePrefix}_tower_arrow_slits`;

  const angles = [-0.6, -0.3, 0, 0.3, 0.6];
  const slitHeights = [
    plinthHeight + shaftHeight * 0.35,
    plinthHeight + shaftHeight * 0.72,
  ];

  slitHeights.forEach((slitY, levelIdx) => {
    angles.forEach((ang, slitIdx) => {
      // Inward angled arrow slit embrasure
      const slitGeom = new THREE.BoxGeometry(0.28, 1.4, 0.9);
      const slitMesh = new THREE.Mesh(slitGeom, materials.fatimidDarkStone);
      const slitDist = radius - 0.3;
      slitMesh.position.set(
        Math.sin(ang) * slitDist,
        slitY,
        Math.cos(ang) * slitDist
      );
      slitMesh.rotation.y = ang;
      slitMesh.name = `${namePrefix}_arrow_slit_L${levelIdx}_${slitIdx}`;
      slitGroup.add(slitMesh);
    });
  });
  towerGroup.add(slitGroup);

  // 5. Corbelled Upper Parapet Platform
  const parapetPlatformHeight = 0.6;
  const parapetPlatformRadius = radius + 0.3;
  const parapetPlatformGeom = new THREE.CylinderGeometry(
    parapetPlatformRadius,
    radius,
    parapetPlatformHeight,
    32,
    1,
    false,
    0,
    Math.PI
  );
  parapetPlatformGeom.rotateY(Math.PI / 2);
  const parapetPlatformMesh = new THREE.Mesh(parapetPlatformGeom, materials.fatimidDarkStone);
  parapetPlatformMesh.name = `${namePrefix}_tower_corbelled_cornice`;
  parapetPlatformMesh.position.set(0, height - 1.8 + parapetPlatformHeight / 2, 0);
  parapetPlatformMesh.castShadow = true;
  towerGroup.add(parapetPlatformMesh);

  // Flat rooftop terrace (base where minaret rests)
  const roofGeom = new THREE.CylinderGeometry(
    radius + 0.2,
    radius + 0.2,
    0.2,
    32,
    1,
    false,
    0,
    Math.PI
  );
  roofGeom.rotateY(Math.PI / 2);
  const roofMesh = new THREE.Mesh(roofGeom, materials.fatimidStone);
  roofMesh.name = `${namePrefix}_tower_terrace`;
  roofMesh.position.set(0, height - 1.8 + parapetPlatformHeight + 0.1, 0);
  roofMesh.receiveShadow = true;
  towerGroup.add(roofMesh);

  // 6. Stepped Battlements / Rounded Merlons & Crenels (Iconic Fatimid Cresting)
  const battlementsGroup = new THREE.Group();
  battlementsGroup.name = `${namePrefix}_tower_crenellations`;
  battlementsGroup.userData = {
    nameEn: 'Fatimid Stepped Crenellations',
    nameAr: 'الشرافات الفاطمية المسننة',
    description: 'Characteristic round-headed stepped battlements crown the rampart.',
  };

  const merlonCount = 11;
  const merlonWidth = 0.8;
  const merlonHeight = 1.35;
  const merlonDepth = 0.55;

  for (let m = 0; m < merlonCount; m++) {
    const fraction = (m + 0.5) / merlonCount;
    const angle = (fraction - 0.5) * Math.PI * 0.92;

    const merlon = new THREE.Group();
    // Base block
    const mBaseGeom = new THREE.BoxGeometry(merlonWidth, merlonHeight * 0.7, merlonDepth);
    const mBase = new THREE.Mesh(mBaseGeom, materials.fatimidStone);
    mBase.position.y = (merlonHeight * 0.7) / 2;
    mBase.castShadow = true;
    merlon.add(mBase);

    // Rounded / stepped cap
    const mCapGeom = new THREE.CylinderGeometry(
      merlonWidth * 0.45,
      merlonWidth * 0.45,
      merlonDepth,
      12,
      1,
      false,
      0,
      Math.PI
    );
    mCapGeom.rotateZ(Math.PI / 2);
    mCapGeom.rotateY(Math.PI / 2);
    const mCap = new THREE.Mesh(mCapGeom, materials.fatimidStone);
    mCap.position.y = merlonHeight * 0.7;
    mCap.castShadow = true;
    merlon.add(mCap);

    const rDist = parapetPlatformRadius - merlonDepth / 2 - 0.05;
    merlon.position.set(
      Math.sin(angle) * rDist,
      height - 1.8 + parapetPlatformHeight + 0.2,
      Math.cos(angle) * rDist
    );
    merlon.rotation.y = angle;
    merlon.name = `${namePrefix}_merlon_${m}`;
    battlementsGroup.add(merlon);
  }
  towerGroup.add(battlementsGroup);

  // Soft contact shadow directly under tower base
  const shadowGeom = new THREE.PlaneGeometry(radius * 3.2, radius * 3.2);
  shadowGeom.rotateX(-Math.PI / 2);
  const shadowMesh = new THREE.Mesh(shadowGeom, materials.contactShadow);
  shadowMesh.name = `${namePrefix}_tower_contact_shadow`;
  shadowMesh.position.set(0, 0.02, 0);
  towerGroup.add(shadowMesh);

  return towerGroup;
}
