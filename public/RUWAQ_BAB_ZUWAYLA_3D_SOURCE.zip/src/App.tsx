/**
 * RUWAQ: Bab Zuwayla 3D Architectural Reconstruction
 * Main Application Component
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { BabZuwaylaScene } from './three/BabZuwaylaScene.ts';
import {
  ViewerState,
  ComponentVisibility,
  MaterialSettings,
  AnnotationItem,
  RemotionTimelineState,
} from './types.ts';

import { Header } from './components/Header.tsx';
import { ControlDock } from './components/ControlDock.tsx';
import { ViewportDraftingOverlay } from './components/ViewportDraftingOverlay.tsx';
import { ComponentInfoModal } from './components/ComponentInfoModal.tsx';
import { RemotionModal } from './components/RemotionModal.tsx';
import { AssetManifestModal } from './components/AssetManifestModal.tsx';
import { ProductionHandoffModal } from './components/ProductionHandoffModal.tsx';

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<BabZuwaylaScene | null>(null);

  // Application States
  const [currentState, setCurrentState] = useState<ViewerState>('FULLY_ASSEMBLED');
  const [cameraMode, setCameraMode] = useState<'perspective' | 'orthographic'>('perspective');
  const [explodedProgress, setExplodedProgress] = useState<number>(0);
  const [minaretElevation, setMinaretElevation] = useState<number>(0);
  const [towerSeparation, setTowerSeparation] = useState<number>(0);
  const [doorAngleDeg, setDoorAngleDeg] = useState<number>(35);

  const [visibility, setVisibility] = useState<ComponentVisibility>({
    leftTower: true,
    rightTower: true,
    centralArch: true,
    gatePassage: true,
    leftDoor: true,
    rightDoor: true,
    leftMinaret: true,
    rightMinaret: true,
    crenellations: true,
    ground: true,
  });

  const [materialSettings, setMaterialSettings] = useState<MaterialSettings>({
    stoneRoughness: 0.82,
    stoneWarmth: 0.55,
    wireframe: false,
    blueprintMode: false,
    shadowIntensity: 0.45,
    aoIntensity: 1.0,
  });

  const [timeline, setTimeline] = useState<RemotionTimelineState>({
    frame: 285,
    totalFrames: 300,
    fps: 30,
    isPlaying: false,
    loop: true,
    speed: 1.0,
  });

  // UI Modals & Inspection
  const [selectedComponent, setSelectedComponent] = useState<{
    id: string;
    nameEn: string;
    nameAr: string;
    descriptionEn?: string;
    descriptionAr?: string;
    era?: string;
    certainty?: string;
  } | null>(null);

  const [selectedAnnotation, setSelectedAnnotation] = useState<AnnotationItem | null>(null);
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [cinemaMode, setCinemaMode] = useState<boolean>(false);
  const [showRemotionModal, setShowRemotionModal] = useState<boolean>(false);
  const [showManifestModal, setShowManifestModal] = useState<boolean>(false);
  const [showHandoffModal, setShowHandoffModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3200);
  };

  // 1. Initialize Scene Lifecycle inside isolated ref container
  useEffect(() => {
    if (!canvasMountRef.current) return;

    const scene = new BabZuwaylaScene(canvasMountRef.current, {
      onSelectComponent: (comp) => {
        setSelectedComponent(comp);
        setSelectedAnnotation(null);
      },
      onSelectAnnotation: (annot) => {
        setSelectedAnnotation(annot);
        setSelectedComponent(null);
      },
    });

    sceneRef.current = scene;

    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
  }, []);

  // 2. Select Architectural State
  const handleSelectState = useCallback((state: ViewerState) => {
    setCurrentState(state);
    if (!sceneRef.current) return;

    sceneRef.current.setState(state);
    setCameraMode(sceneRef.current.activeCamera === sceneRef.current.orthographicCamera ? 'orthographic' : 'perspective');

    if (state === 'FATIMID_ORIGINAL') {
      setVisibility((prev) => ({ ...prev, leftMinaret: false, rightMinaret: false }));
      setExplodedProgress(0);
    } else if (state === 'EXPLODED_VIEW') {
      setExplodedProgress(0.75);
      setDoorAngleDeg(70);
    } else {
      setVisibility((prev) => ({ ...prev, leftMinaret: true, rightMinaret: true }));
      setExplodedProgress(0);
    }
  }, []);

  // 3. Toggle Camera Mode
  const handleToggleCameraMode = () => {
    if (!sceneRef.current) return;
    const nextMode = cameraMode === 'perspective' ? 'orthographic' : 'perspective';
    sceneRef.current.switchCameraMode(nextMode);
    setCameraMode(nextMode);
  };

  // 4. Update Exploded Progress
  const handleExplodedProgress = (val: number) => {
    setExplodedProgress(val);
    if (sceneRef.current) {
      sceneRef.current.setExplodedProgress(val);
    }
  };

  const handleMinaretElevation = (val: number) => {
    setMinaretElevation(val);
    if (sceneRef.current) {
      sceneRef.current.setMinaretElevation(val);
    }
  };

  const handleTowerSeparation = (val: number) => {
    setTowerSeparation(val);
    if (sceneRef.current) {
      sceneRef.current.setTowerSeparation(val);
    }
  };

  const handleDoorAngle = (val: number) => {
    setDoorAngleDeg(val);
    if (sceneRef.current) {
      sceneRef.current.setDoorAngle(val);
    }
  };

  // 5. Component Visibility Update
  const handleVisibility = (updater: Partial<ComponentVisibility>) => {
    const updated = { ...visibility, ...updater };
    setVisibility(updated);
    if (sceneRef.current) {
      sceneRef.current.setComponentVisibility(updated);
    }
  };

  // 6. Material Settings Update
  const handleMaterialSettings = (updater: Partial<MaterialSettings>) => {
    const updated = { ...materialSettings, ...updater };
    setMaterialSettings(updated);
    if (sceneRef.current) {
      sceneRef.current.setMaterialSettings(updated);
    }
  };

  // 7. Timeline / Remotion Seek
  const handleSeekFrame = useCallback((frame: number) => {
    setTimeline((prev) => ({ ...prev, frame }));
    if (sceneRef.current) {
      sceneRef.current.seekFrame(frame, timeline.totalFrames);
      setCurrentState(sceneRef.current.currentState);
      setCameraMode(
        sceneRef.current.activeCamera === sceneRef.current.orthographicCamera
          ? 'orthographic'
          : 'perspective'
      );
      setExplodedProgress(sceneRef.current.explodedProgress);
    }
  }, [timeline.totalFrames]);

  // 8. Select Hotspot
  const handleSelectAnnotation = (item: AnnotationItem) => {
    setSelectedAnnotation(item);
    setSelectedComponent(null);
  };

  // 9. Reset Scene
  const handleReset = () => {
    handleSelectState('FULLY_ASSEMBLED');
    setExplodedProgress(0);
    setMinaretElevation(0);
    setTowerSeparation(0);
    setDoorAngleDeg(35);
    setMaterialSettings({
      stoneRoughness: 0.82,
      stoneWarmth: 0.55,
      wireframe: false,
      blueprintMode: false,
      shadowIntensity: 0.45,
      aoIntensity: 1.0,
    });
    setTimeline((prev) => ({ ...prev, frame: 285, isPlaying: false }));
    showToast('Scene reset to default assembled state');
  };

  // 10. GLB Export
  const handleExportGLB = () => {
    if (!sceneRef.current) return;
    showToast('Exporting GLB with preserved named hierarchy...');
    sceneRef.current.exportGLB();
  };

  // 11. High-Res Snapshot
  const handleSnapshot = () => {
    if (!sceneRef.current) return;
    const dataUrl = sceneRef.current.captureSnapshot();
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `RUWAQ_Bab_Zuwayla_${currentState}_${Date.now()}.png`;
    link.click();
    showToast(`Captured high-res plate: ${currentState}`);
  };

  // 12. Keyboard Shortcuts (1-8 for states, Space for play, H for cinema mode)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key >= '1' && e.key <= '8') {
        const stateKeys: ViewerState[] = [
          'FATIMID_ORIGINAL',
          'TOP_PLAN',
          'SIDE_ELEVATION',
          'FRONT_ELEVATION',
          'PERSPECTIVE_3Q',
          'MAMLUK_ADDITIONS',
          'EXPLODED_VIEW',
          'FULLY_ASSEMBLED',
        ];
        const idx = parseInt(e.key, 10) - 1;
        if (stateKeys[idx]) {
          handleSelectState(stateKeys[idx]);
        }
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        setTimeline((prev) => ({ ...prev, isPlaying: !prev.isPlaying }));
      } else if (e.key === 'h' || e.key === 'H') {
        setIsCollapsed((prev) => !prev);
      } else if (e.key === 'Escape') {
        setSelectedComponent(null);
        setSelectedAnnotation(null);
        setShowRemotionModal(false);
        setShowManifestModal(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSelectState]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#F3EBDB] select-none">
      {/* 1. Isolated WebGL Canvas Container */}
      <div
        ref={canvasMountRef}
        className="w-full h-full absolute inset-0 z-0 cursor-grab active:cursor-grabbing"
      />

      {/* 2. Viewport Architectural Drafting Markings */}
      {!cinemaMode && (
        <ViewportDraftingOverlay
          currentState={currentState}
          cameraMode={cameraMode}
        />
      )}

      {/* 3. Header Bar */}
      {!cinemaMode && (
        <Header
          currentState={currentState}
          onReset={handleReset}
          onExportGLB={handleExportGLB}
          onSnapshot={handleSnapshot}
          onOpenRemotion={() => setShowRemotionModal(true)}
          onOpenManifest={() => setShowManifestModal(true)}
          onOpenHandoff={() => setShowHandoffModal(true)}
          cinemaMode={cinemaMode}
          onToggleCinemaMode={() => setCinemaMode(!cinemaMode)}
        />
      )}

      {/* 4. Collapsible Bottom Control Dock */}
      {!cinemaMode && (
        <ControlDock
          currentState={currentState}
          onSelectState={handleSelectState}
          cameraMode={cameraMode}
          onToggleCameraMode={handleToggleCameraMode}
          explodedProgress={explodedProgress}
          onChangeExplodedProgress={handleExplodedProgress}
          minaretElevation={minaretElevation}
          onChangeMinaretElevation={handleMinaretElevation}
          towerSeparation={towerSeparation}
          onChangeTowerSeparation={handleTowerSeparation}
          doorAngleDeg={doorAngleDeg}
          onChangeDoorAngle={handleDoorAngle}
          visibility={visibility}
          onChangeVisibility={handleVisibility}
          materialSettings={materialSettings}
          onChangeMaterialSettings={handleMaterialSettings}
          timeline={timeline}
          onUpdateTimeline={(updater) => setTimeline((prev) => ({ ...prev, ...updater }))}
          onSeekFrame={handleSeekFrame}
          onSelectAnnotation={handleSelectAnnotation}
          isCollapsed={isCollapsed}
          onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
        />
      )}

      {/* 5. Cinema Mode Floating Restore Button */}
      {cinemaMode && (
        <button
          onClick={() => setCinemaMode(false)}
          className="absolute top-4 right-4 z-50 px-3 py-1.5 rounded-lg bg-[#1C1B19]/90 text-[#A98A4B] text-xs font-mono-doc border border-[#A98A4B]/50 hover:bg-[#1C1B19] transition-all shadow-xl"
        >
          Exit Cinema Mode (H)
        </button>
      )}

      {/* 6. Component / Hotspot Info Card */}
      <ComponentInfoModal
        selectedComponent={selectedComponent}
        selectedAnnotation={selectedAnnotation}
        onClose={() => {
          setSelectedComponent(null);
          setSelectedAnnotation(null);
        }}
      />

      {/* 7. Remotion Integration Guide Modal */}
      <RemotionModal
        isOpen={showRemotionModal}
        onClose={() => setShowRemotionModal(false)}
      />

      {/* 8. Asset Manifest & Historical Safety Modal */}
      <AssetManifestModal
        isOpen={showManifestModal}
        onClose={() => setShowManifestModal(false)}
      />

      {/* 9. Production Deliverables & Handoff Hub */}
      <ProductionHandoffModal
        isOpen={showHandoffModal}
        onClose={() => setShowHandoffModal(false)}
      />

      {/* 9. Notification Toast */}
      {toastMessage && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-50 bg-[#1C1B19]/95 text-[#F3EBDB] border border-[#A98A4B] px-4 py-2 rounded-lg shadow-xl text-xs font-mono-doc flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#A98A4B]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </main>
  );
}
