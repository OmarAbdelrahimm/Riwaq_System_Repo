/**
 * RUWAQ Documentary Header Component
 */

import React from 'react';
import { Camera, Download, Film, Layers, Maximize2, RotateCcw } from 'lucide-react';
import { ViewerState } from '../types.ts';

interface HeaderProps {
  currentState: ViewerState;
  onReset: () => void;
  onExportGLB: () => void;
  onSnapshot: () => void;
  onOpenRemotion: () => void;
  onOpenManifest: () => void;
  onOpenHandoff: () => void;
  cinemaMode: boolean;
  onToggleCinemaMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentState,
  onReset,
  onExportGLB,
  onSnapshot,
  onOpenRemotion,
  onOpenManifest,
  onOpenHandoff,
  cinemaMode,
  onToggleCinemaMode,
}) => {
  return (
    <header className="absolute top-0 left-0 right-0 z-20 pointer-events-none p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
      {/* Brand & Documentary Title */}
      <div className="pointer-events-auto flex items-center gap-3 bg-[#1C1B19]/90 text-[#F3EBDB] px-4 py-2.5 rounded-lg border border-[#A98A4B]/40 shadow-xl backdrop-blur-none">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="font-serif-doc text-xs tracking-[0.25em] text-[#A98A4B] font-bold uppercase">
              RUWAQ
            </span>
            <span className="text-[#A98A4B]/50 text-xs">•</span>
            <span className="font-arabic text-sm text-[#F3EBDB]/90">
              رواق للتوثيق المعماري
            </span>
          </div>
          <h1 className="font-serif-doc text-base font-bold text-[#F3EBDB] tracking-wide flex items-center gap-2">
            BAB ZUWAYLA
            <span className="font-arabic text-[#A98A4B] font-normal text-sm">باب زويلة</span>
          </h1>
        </div>

        <div className="h-7 w-[1px] bg-[#A98A4B]/30 mx-1 hidden sm:block" />

        {/* Chronological State Badge */}
        <div className="hidden sm:flex flex-col text-left">
          <span className="text-[10px] tracking-wider text-[#A98A4B] font-mono-doc uppercase">
            CHRONOLOGY
          </span>
          <span className="text-xs text-[#F3EBDB]/90 font-medium font-mono-doc">
            {currentState === 'FATIMID_ORIGINAL' ? (
              <span className="text-[#F3EBDB]">1092 CE (Fatimid Only)</span>
            ) : (
              <span>1092 ➔ 1415–1421 CE</span>
            )}
          </span>
        </div>
      </div>

      {/* Educational Reconstruction & Toolbar */}
      <div className="pointer-events-auto flex items-center gap-2 flex-wrap">
        <div className="hidden lg:flex items-center gap-2 bg-[#F3EBDB]/90 text-[#1C1B19] border border-[#A98A4B]/50 px-3 py-1.5 rounded-md text-[11px] font-mono-doc shadow-sm">
          <span className="w-2 h-2 rounded-full bg-[#A98A4B]" />
          <span>Educational Reconstruction • Model based on in-situ surveys</span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 bg-[#1C1B19]/90 border border-[#A98A4B]/40 p-1 rounded-lg shadow-lg">
          <button
            onClick={onOpenHandoff}
            title="Open RUWAQ Production Deliverables & Handoff Hub"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs text-[#1C1B19] bg-[#A98A4B] hover:bg-[#c4a45e] transition-colors font-bold shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Deliverables & Film</span>
          </button>

          <button
            onClick={onSnapshot}
            title="Capture Documentary High-Res Plate"
            className="flex items-center gap-1.5 px-2 py-1.5 rounded text-xs text-[#F3EBDB] hover:bg-[#A98A4B]/20 hover:text-[#A98A4B] transition-colors"
          >
            <Camera className="w-3.5 h-3.5 text-[#A98A4B]" />
            <span className="hidden sm:inline">Plate</span>
          </button>

          <button
            onClick={onExportGLB}
            title="Download Master GLB (Preserves Named Objects)"
            className="flex items-center gap-1.5 px-2 py-1.5 rounded text-xs text-[#F3EBDB] hover:bg-[#A98A4B]/20 hover:text-[#A98A4B] transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-[#A98A4B]" />
            <span className="hidden sm:inline">GLB</span>
          </button>

          <button
            onClick={onOpenRemotion}
            title="Remotion Integration Code & Timeline Scrubber"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs text-[#A98A4B] bg-[#A98A4B]/15 hover:bg-[#A98A4B]/30 transition-colors font-medium"
          >
            <Film className="w-3.5 h-3.5" />
            <span>Remotion</span>
          </button>

          <button
            onClick={onOpenManifest}
            title="Architectural Manifest & Storyboard References"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs text-[#F3EBDB] hover:bg-[#A98A4B]/20 hover:text-[#A98A4B] transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-[#A98A4B]" />
            <span className="hidden sm:inline">Manifest</span>
          </button>

          <button
            onClick={onReset}
            title="Reset Scene and Camera"
            className="p-1.5 rounded text-xs text-[#F3EBDB]/80 hover:text-[#F3EBDB] hover:bg-[#F3EBDB]/10 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onToggleCinemaMode}
            title={cinemaMode ? 'Show Controls (H)' : 'Cinema Fullscreen View (H)'}
            className="p-1.5 rounded text-xs text-[#A98A4B] hover:bg-[#A98A4B]/20 transition-colors"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
