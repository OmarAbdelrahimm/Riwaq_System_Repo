import React from 'react';
import { Composition } from 'remotion';
import { BabZuwaylaRemotion } from './BabZuwaylaRemotion.tsx';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="RuwaqBabZuwayla"
      component={BabZuwaylaRemotion}
      durationInFrames={300}
      fps={30}
      width={1920}
      height={1080}
      defaultProps={{
        showAnnotations: false,
      }}
    />
  );
};
